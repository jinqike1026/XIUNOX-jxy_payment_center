<?php
!defined('DEBUG') AND exit('Access Denied');
global $db;
// 保留 db_exec
db_exec("DROP TABLE IF EXISTS {$db->tablepre}pc_wechat_user");
// 保留 db_exec
db_exec("DROP TABLE IF EXISTS {$db->tablepre}pc_payment_order");
setting_set('payment_center',null);
