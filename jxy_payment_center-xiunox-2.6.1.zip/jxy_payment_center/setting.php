<?php
!defined('DEBUG') AND exit('Access Denied');
$gid!=1&&$gid!=2 AND message(-1,'无权限');
if(!class_exists('PaymentCenterService',false)) include_once APP_PATH.'plugin/jxy_payment_center/model/PaymentCenterService.php';
class_exists('PaymentCenterService',false) OR message(-1,'支付中心服务加载失败，请清理 tmp/model.min.php');
$tab=param('tab','settings');$page=max(1,param('page',1));
$statusFilter=param('status','');$channelFilter=param('channel','');$keyword=trim(param('keyword','',FALSE));
if($method==='POST'&&!empty($_POST)){
 CsrfService::check();$a=param('payment_admin_action','');
 if($a==='filter'){
  $postedStatus=isset($_POST['status'])?strval($_POST['status']):'';
  $postedStatus=in_array($postedStatus,array('','0','1','2','9'),true)?$postedStatus:'';
  $postedChannel=isset($_POST['channel'])?strval($_POST['channel']):'';
  $postedChannel=in_array($postedChannel,array('','alipay','wechat_native','wechat_h5','wechat_jsapi','epay_alipay','epay_wxpay'),true)?$postedChannel:'';
  $postedKeyword=isset($_POST['keyword'])?trim(strval($_POST['keyword'])):'';
  $postedKeyword=preg_replace('/[^A-Za-z0-9_-]/','',$postedKeyword);
  http_location(admin_plugin_setting_url('jxy_payment_center',array('tab'=>'orders','status'=>$postedStatus,'channel'=>$postedChannel,'keyword'=>$postedKeyword)));
 }
 if($a==='save'){
  $old=PaymentCenterService::settings();$secretFields=array('alipay_private_key','alipay_public_key','wechat_app_secret','wechat_private_key','wechat_api_v3_key','wechat_platform_cert','epay_key','epay_private_key','epay_public_key');
  $postedPresetAmounts=param('preset_amounts',array());$postedPresetBonuses=param('preset_bonuses',array());$presetAmounts=array();$presetBonuses=array();for($i=0;$i<6;$i++){$presetAmounts[$i]=max(1,min(100000,intval($postedPresetAmounts[$i]??0)));$presetBonuses[$i]=max(0,min(1000000000,intval($postedPresetBonuses[$i]??0)));}
  $s=array('enabled'=>param('enabled',0),'show_nav'=>param('show_nav',0),'channels'=>array_values(array_intersect(param('channels',array()),array('alipay','wechat_native','wechat_h5','wechat_jsapi','epay_alipay','epay_wxpay'))),'min_amount'=>max(1,param('min_amount',1)),'max_amount'=>max(1,param('max_amount',10000)),'order_expire'=>max(300,param('order_expire',1800)),'ratio_rmbs'=>max(1,min(100000,param('ratio_rmbs',1))),'ratio_credits'=>max(1,min(100000,param('ratio_credits',10))),'ratio_golds'=>max(1,min(100000,param('ratio_golds',1))),'preset_amounts'=>$presetAmounts,'preset_bonuses'=>$presetBonuses,'alipay_appid'=>trim(param('alipay_appid','',FALSE)),'alipay_gateway'=>trim(param('alipay_gateway','https://openapi.alipay.com/gateway.do',FALSE)),'alipay_mode'=>in_array(param('alipay_mode','f2f'),array('f2f','web'),true)?param('alipay_mode','f2f'):'f2f','wechat_appid'=>trim(param('wechat_appid','',FALSE)),'wechat_mchid'=>trim(param('wechat_mchid','',FALSE)),'wechat_serial_no'=>trim(param('wechat_serial_no','',FALSE)),'epay_version'=>in_array(param('epay_version','v1'),array('v1','v2'),true)?param('epay_version','v1'):'v1','epay_gateway'=>rtrim(trim(param('epay_gateway','',FALSE)),'/'),'epay_pid'=>trim(param('epay_pid','',FALSE)),'notice'=>mb_substr(param('notice','',FALSE),0,255));
  foreach($secretFields as $f){$v=param($f,'',FALSE);$s[$f]=$v===''?($old[$f]??''):$v;}
  empty($s['channels']) AND message(-1,'至少启用一种支付方式');$s['max_amount']<$s['min_amount'] AND message(-1,'最高金额不能低于最低金额');foreach($s['preset_amounts'] as $presetAmount){($presetAmount<$s['min_amount']||$presetAmount>$s['max_amount']) AND message(-1,'固定充值金额必须在最低和最高金额范围内');}
  PaymentCenterService::saveSettings($s);message(0,'设置已保存',array('redirect_url'=>admin_plugin_setting_url('jxy_payment_center')));
 }
 if($a==='cleanup_status'){
  $cleanupStatus=isset($_POST['cleanup_status'])?strval($_POST['cleanup_status']):'';
  in_array($cleanupStatus,array('0','1','2','9'),true) OR message(-1,'请先选择需要清理的订单状态');
  PaymentCenterService::cleanupOrders(intval($cleanupStatus));
  message(0,'所选状态的订单已清理；用户余额和核心积分日志未修改',array('redirect_url'=>admin_plugin_setting_url('jxy_payment_center',array('tab'=>'orders','status'=>$cleanupStatus,'channel'=>$channelFilter,'keyword'=>$keyword))));
 }
 if($a==='cleanup_all'){PaymentCenterService::cleanupOrders(null);message(0,'全部订单记录已清理；用户余额和核心积分日志未修改',array('redirect_url'=>admin_plugin_setting_url('jxy_payment_center',array('tab'=>'orders'))));}
}
$s=PaymentCenterService::settings();$orders=array();$pagination='';$statusOrderCount=0;
if($tab==='orders'){$r=PaymentCenterService::adminOrders($statusFilter,$channelFilter,$keyword,$page,20);$orders=$r['list'];if($statusFilter!=='')$statusOrderCount=PaymentCenterService::adminStatusOrderCount($statusFilter);$pagination=pagination(admin_plugin_setting_url('jxy_payment_center',array('tab'=>'orders','status'=>$statusFilter,'channel'=>$channelFilter,'keyword'=>$keyword,'page'=>'{page}')),intval($r['total']),$page,20);}
$header['title']='支付中心';include _include(APP_PATH.'plugin/jxy_payment_center/view/htm/setting.htm');
