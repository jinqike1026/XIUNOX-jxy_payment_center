<?php exit;
// 支付宝、微信与易支付异步通知必须在全局 CSRF 前独立处理；此入口只做签名验签，不信任会话。
if($route==='paycenter'&&param(1,'')==='notify'&&in_array(param(2,''),array('alipay','wechat','epay'),true)){
 include _include(APP_PATH.'plugin/jxy_payment_center/route/notify.php');exit;
}
