<?php exit;
case 'paycenter': include _include(APP_PATH.'plugin/jxy_payment_center/route/paycenter.php'); break;
