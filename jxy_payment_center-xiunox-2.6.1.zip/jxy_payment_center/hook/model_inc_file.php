<?php exit;
APP_PATH.'plugin/jxy_payment_center/model/AlipayOfficialService.php',
APP_PATH.'plugin/jxy_payment_center/model/WechatPayV3Service.php',
APP_PATH.'plugin/jxy_payment_center/model/PaymentCenterService.php',
