<?php
!defined('DEBUG') AND exit('Access Denied');
if(!class_exists('AlipayOfficialService')) include_once APP_PATH.'plugin/jxy_payment_center/model/AlipayOfficialService.php';
if(!class_exists('WechatPayV3Service')) include_once APP_PATH.'plugin/jxy_payment_center/model/WechatPayV3Service.php';
if(!class_exists('EpayService')) include_once APP_PATH.'plugin/jxy_payment_center/model/EpayService.php';

class PaymentCenterService {
    const PENDING=0; const PAID=1; const CLOSED=2; const PROCESSING=9;

    public static function defaults() {
        return array(
            'enabled'=>0, 'show_nav'=>1, 'channels'=>array('alipay','wechat_native','wechat_h5','wechat_jsapi'),
            'min_amount'=>1, 'max_amount'=>10000, 'order_expire'=>1800,
            'ratio_rmbs'=>1, 'ratio_credits'=>10, 'ratio_golds'=>1,
            'preset_amounts'=>array(1,5,10,30,50,100), 'preset_bonuses'=>array(0,0,0,0,0,0),
            'alipay_appid'=>'', 'alipay_private_key'=>'', 'alipay_public_key'=>'',
            'alipay_gateway'=>'https://openapi.alipay.com/gateway.do', 'alipay_mode'=>'f2f',
            'wechat_appid'=>'', 'wechat_app_secret'=>'', 'wechat_mchid'=>'', 'wechat_serial_no'=>'',
            'wechat_private_key'=>'', 'wechat_api_v3_key'=>'', 'wechat_platform_cert'=>'',
            'epay_version'=>'v1', 'epay_gateway'=>'', 'epay_pid'=>'', 'epay_key'=>'',
            'epay_private_key'=>'', 'epay_public_key'=>'',
            'notice'=>'充值到账以支付平台异步通知为准，请勿重复付款。',
        );
    }

    public static function settings() {
        $s=setting_get('payment_center');
        return is_array($s) ? array_merge(self::defaults(),$s) : self::defaults();
    }

    public static function saveSettings($s) { return setting_set('payment_center',$s); }

    public static function creditTypes() { return array('rmbs','credits','golds'); }

    public static function creditTypeLabel($type) {
        $labels=array('rmbs'=>'RMB','credits'=>'积分','golds'=>'金币');
        return $labels[$type]??'RMB';
    }

    public static function ratioFor($type,$settings=null) {
        $settings=is_array($settings)?$settings:self::settings();
        return max(1,min(100000,intval($settings['ratio_'.$type]??1)));
    }

    public static function createOrder($uid,$amount,$channel,$creditType='rmbs',$presetSlot=-1) {
        $s=self::settings(); $uid=intval($uid); $amount=intval($amount);
        if(empty($s['enabled'])) return array('ok'=>false,'message'=>lang('pc_disabled'));
        if($amount<intval($s['min_amount'])||$amount>intval($s['max_amount'])) return array('ok'=>false,'message'=>lang('pc_amount_error'));
        if(!in_array($channel,$s['channels'],true)) return array('ok'=>false,'message'=>lang('pc_channel_error'));
        if(!in_array($creditType,self::creditTypes(),true)) return array('ok'=>false,'message'=>'请选择有效的充值资产');
        $presetSlot=intval($presetSlot);$bonusAmount=0;
        if($presetSlot>=0&&$presetSlot<6){$presetAmounts=is_array($s['preset_amounts']??null)?$s['preset_amounts']:array();$presetBonuses=is_array($s['preset_bonuses']??null)?$s['preset_bonuses']:array();$presetAmount=intval($presetAmounts[$presetSlot]??0);if($presetAmount<=0||$amount!==$presetAmount)return array('ok'=>false,'message'=>'固定充值金额已变更，请重新选择');$bonusAmount=max(0,min(1000000000,intval($presetBonuses[$presetSlot]??0)));}
        $creditAmount=$amount*self::ratioFor($creditType,$s)+$bonusAmount;
        if($creditAmount<=0||$creditAmount>1000000000) return array('ok'=>false,'message'=>'充值比例计算结果超出允许范围');
        $no='PC'.date('YmdHis').str_pad(strval($uid%10000),4,'0',STR_PAD_LEFT).substr(xn_rand(4),0,4);
        $subject=self::creditTypeLabel($creditType).'充值';
        $id=db_insert('pc_payment_order',array(
            'order_no'=>$no,'uid'=>$uid,'amount'=>$amount,'channel'=>$channel,'subject'=>$subject,
            'credit_type'=>$creditType,'credit_amount'=>$creditAmount,'bonus_amount'=>$bonusAmount,'status'=>self::PENDING,
            'provider_trade_no'=>'','client_ip'=>intval(sprintf('%u',ip2long(ip()))),
            'created'=>time(),'paid_at'=>0,'updated'=>time(),'pay_payload'=>'','callback_raw'=>'',
        ));
        return $id?array('ok'=>true,'order'=>db_find_one('pc_payment_order',array('id'=>intval($id)))):array('ok'=>false,'message'=>lang('pc_order_failed'));
    }

    public static function start($order,$uid) {
        $s=self::settings(); $channel=$order['channel'];
        if(in_array($channel,array('epay_alipay','epay_wxpay'),true)){
            $epayVersion=($s['epay_version']??'v1')==='v2'?'v2':'v1';
            $r=EpayService::create($order,$s,self::absoluteUrl(route_url('paycenter_notify_epay')),self::absoluteUrl(route_url('paycenter_return',array('order_no'=>$order['order_no']))));
            if($r['type']==='native'){self::storePayload($order['id'],array('code_url'=>$r['code_url'],'epay_version'=>$epayVersion));return array('type'=>'native','provider'=>'epay','order'=>$order);}
            self::storePayload($order['id'],array('epay_version'=>$epayVersion));return array('type'=>'redirect','url'=>$r['url']);
        }
        if($channel==='alipay') {
            if(($s['alipay_mode']??'f2f')==='f2f') {
                $r=AlipayOfficialService::precreate($order,$s,self::absoluteUrl(route_url('paycenter_notify_alipay')));
                self::storePayload($order['id'],array('code_url'=>$r['qr_code']));
                return array('type'=>'native','provider'=>'alipay','order'=>$order);
            }
            $mobile=stripos($_SERVER['HTTP_USER_AGENT']??'','Mobile')!==false;
            return array('type'=>'redirect','url'=>AlipayOfficialService::payUrl($order,$s,self::absoluteUrl(route_url('paycenter_notify_alipay')),self::absoluteUrl(route_url('paycenter_return',array('order_no'=>$order['order_no']))),$mobile));
        }
        $notify=self::absoluteUrl(route_url('paycenter_notify_wechat'));
        if($channel==='wechat_jsapi') {
            $openid=self::openid($uid);
            if(!$openid) return array('type'=>'redirect','url'=>WechatPayV3Service::oauthUrl($order['order_no'],$s,self::absoluteUrl(route_url('paycenter_wechat_oauth'))));
            $r=WechatPayV3Service::create($order,$channel,$openid,$s,$notify);
            $payload=WechatPayV3Service::jsapiParams($r['prepay_id'],$s);
            self::storePayload($order['id'],$payload);
            return array('type'=>'jsapi','payload'=>$payload,'order'=>$order);
        }
        $r=WechatPayV3Service::create($order,$channel,'',$s,$notify);
        if($channel==='wechat_h5') return array('type'=>'redirect','url'=>$r['h5_url']);
        self::storePayload($order['id'],array('code_url'=>$r['code_url']));
        return array('type'=>'native','order'=>$order);
    }

    private static function absoluteUrl($url) {
        $url=strval($url);if(preg_match('#^https?://#i',$url))return $url;
        $p=parse_url(http_url_path());$scheme=strtolower(strval($p['scheme']??''));$host=strval($p['host']??'');
        if(!in_array($scheme,array('http','https'),true)||$host==='')throw new Exception('无法生成支付回调地址');
        $port=isset($p['port'])?':'.intval($p['port']):'';
        return $scheme.'://'.$host.$port.'/'.ltrim($url,'/');
    }

    public static function handleAlipay($p) {
        $s=self::settings();
        if(!AlipayOfficialService::verify($p,$s['alipay_public_key'])) return false;
        if(($p['app_id']??'')!==trim($s['alipay_appid'])) return false;
        if(!in_array($p['trade_status']??'',array('TRADE_SUCCESS','TRADE_FINISHED'),true)) return false;
        return self::credit($p['out_trade_no']??'',floatval($p['total_amount']??0),$p['trade_no']??'',array('provider'=>'alipay','data'=>$p));
    }

    public static function handleWechat($headers,$body) {
        $s=self::settings(); $d=WechatPayV3Service::verifyAndDecrypt($headers,$body,$s);
        if(!$d||($d['trade_state']??'')!=='SUCCESS'||($d['mchid']??'')!==trim($s['wechat_mchid'])||($d['appid']??'')!==trim($s['wechat_appid'])) return false;
        return self::credit($d['out_trade_no']??'',floatval(($d['amount']['total']??0)/100),$d['transaction_id']??'',array('provider'=>'wechat','data'=>$d));
    }

    public static function handleEpay($p) {
        $s=self::settings();if(!EpayService::verifyNotify($p,$s))return false;
        if(($p['trade_status']??'')!=='TRADE_SUCCESS')return false;
        $o=db_find_one('pc_payment_order',array('order_no'=>strval($p['out_trade_no']??'')));
        if(!$o||!in_array($o['channel'],array('epay_alipay','epay_wxpay'),true))return false;
        $payload=xn_json_decode($o['pay_payload']??'');$expectedVersion=is_array($payload)?strval($payload['epay_version']??''):'';$notifyVersion=strtoupper(strval($p['sign_type']??''))==='MD5'?'v1':'v2';if($expectedVersion!==''&&$expectedVersion!==$notifyVersion)return false;
        $expected=$o['channel']==='epay_wxpay'?'wxpay':'alipay';if(($p['type']??'')!==$expected)return false;
        return self::credit($p['out_trade_no']??'',floatval($p['money']??0),$p['trade_no']??'',array('provider'=>'epay','data'=>$p));
    }

    public static function reconcileAlipay($no,$uid) {
        $o=self::order(strval($no),intval($uid));if(!$o||$o['channel']!=='alipay')return false;
        if(intval($o['status'])===self::PAID)return true;if(intval($o['status'])!==self::PENDING)return false;
        $r=AlipayOfficialService::query($o,self::settings());
        if(($r['code']??'')!=='10000'||!in_array($r['trade_status']??'',array('TRADE_SUCCESS','TRADE_FINISHED'),true))return false;
        if(strval($r['out_trade_no']??'')!==strval($o['order_no']))return false;
        return self::credit($o['order_no'],floatval($r['total_amount']??0),strval($r['trade_no']??''),array('provider'=>'alipay_query','data'=>$r));
    }

    private static function credit($no,$amount,$trade,$raw) {
        global $db,$conf;
        $o=db_find_one('pc_payment_order',array('order_no'=>$no));
        if(!$o) return false;
        if(intval($o['status'])===self::PAID) return true;
        if(number_format($amount,2,'.','')!==number_format(intval($o['amount']),2,'.','')) return false;
        $type=$o['credit_type']??'rmbs';
        if(!in_array($type,self::creditTypes(),true)) return false;
        $creditAmount=intval($o['credit_amount']??0); if($creditAmount<=0)$creditAmount=intval($o['amount']);
        $lock=db_update('pc_payment_order',array('id'=>intval($o['id']),'status'=>self::PENDING),array(
            'status'=>self::PROCESSING,'provider_trade_no'=>mb_substr($trade,0,128),
            'callback_raw'=>mb_substr(xn_json_encode($raw),0,65000),'updated'=>time(),
        ));
        if(!$lock){$x=db_find_one('pc_payment_order',array('id'=>intval($o['id'])));return intval($x['status'])===self::PAID;}
        if(!class_exists('CreditsService')) include_once APP_PATH.'lib/CreditsService.php';
        $c=new CreditsService($db,$conf);
        $reason='支付中心充值：'.self::creditTypeLabel($type).'：'.$no;
        $r=$c->add(intval($o['uid']),$type,$creditAmount,$reason,-1);
        if(empty($r['ok'])){
            db_update('pc_payment_order',array('id'=>intval($o['id']),'status'=>self::PROCESSING),array('status'=>self::PENDING,'updated'=>time()));
            return false;
        }
        db_update('pc_payment_order',array('id'=>intval($o['id']),'status'=>self::PROCESSING),array('status'=>self::PAID,'paid_at'=>time(),'updated'=>time()));
        return true;
    }

    public static function storeOpenid($uid,$openid){$d=array('uid'=>intval($uid),'openid'=>$openid,'updated'=>time());return self::openid($uid)?db_update('pc_wechat_user',array('uid'=>intval($uid)),$d):db_insert('pc_wechat_user',$d);}
    public static function openid($uid){$r=db_find_one('pc_wechat_user',array('uid'=>intval($uid)));return $r['openid']??'';}
    public static function order($no,$uid=0){$c=array('order_no'=>$no);if($uid)$c['uid']=intval($uid);return db_find_one('pc_payment_order',$c);}
    public static function qrPayload($no,$uid){$o=self::order($no,$uid);if(!$o||!in_array($o['channel'],array('wechat_native','alipay'),true))return ''; $p=xn_json_decode($o['pay_payload']);return $p['code_url']??'';}
    private static function storePayload($id,$p){db_update('pc_payment_order',array('id'=>intval($id)),array('pay_payload'=>xn_json_encode($p),'updated'=>time()));}
    public static function orders($uid,$page,$size){$c=intval($uid)>0?array('uid'=>intval($uid)):array();return array('list'=>db_find('pc_payment_order',$c,array('id'=>-1),max(1,intval($page)),intval($size),'id')?:array(),'total'=>db_count('pc_payment_order',$c));}
    public static function adminOrders($status,$channel,$keyword,$page,$size){$c=array();if($status!=='')$c['status']=intval($status);if($channel!=='')$c['channel']=$channel;if($keyword!=='')$c['order_no']=array('LIKE'=>$keyword);$l=db_find('pc_payment_order',$c,array('id'=>-1),max(1,intval($page)),intval($size),'id')?:array();if($l){$u=user_find_by_uids(implode(',',array_values(array_unique(arrlist_values($l,'uid')))));foreach($l as &$r)$r['user']=$u[$r['uid']]??array('display_name'=>'UID '.$r['uid']);}return array('list'=>$l,'total'=>db_count('pc_payment_order',$c));}
    public static function adminStatusOrderCount($status){return db_count('pc_payment_order',array('status'=>intval($status)));}
    public static function cleanupOrders($status=null){$cond=$status===null?array():array('status'=>intval($status));return db_delete('pc_payment_order',$cond);}
    public static function statusLabel($v){$m=array(0=>'pc_pending',1=>'pc_paid',2=>'pc_closed',9=>'pc_processing');return lang($m[intval($v)]??'pc_unknown');}
}
