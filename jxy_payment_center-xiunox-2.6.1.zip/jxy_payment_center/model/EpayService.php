<?php
!defined('DEBUG') AND exit('Access Denied');
class EpayService {
 public static function create($order,$settings,$notifyUrl,$returnUrl){
  $version=($settings['epay_version']??'v1')==='v2'?'v2':'v1';$base=self::base($settings['epay_gateway']??'');
  $type=$order['channel']==='epay_wxpay'?'wxpay':'alipay';
  $p=array('pid'=>trim($settings['epay_pid']??''),'type'=>$type,'out_trade_no'=>$order['order_no'],'notify_url'=>$notifyUrl,'return_url'=>$returnUrl,'name'=>$order['subject'],'money'=>number_format(intval($order['amount']),2,'.',''),'clientip'=>ip(),'device'=>self::device(),'param'=>$order['credit_type'].'|'.intval($order['credit_amount']).'|'.$version);
  if($p['pid']==='')throw new Exception('易支付商户ID未配置');
  if($version==='v2'){$p['timestamp']=strval(time());$p['sign_type']='RSA';$p['sign']=self::rsaSign($p,$settings['epay_private_key']??'');$url=$base.'/api/v2/pay/create';}
  else{$p['sign_type']='MD5';$p['sign']=self::md5Sign($p,$settings['epay_key']??'');return array('type'=>'redirect','url'=>self::safeRedirect($base.'/submit.php?'.http_build_query($p,'','&',PHP_QUERY_RFC3986)),'trade_no'=>'');}
  $raw=self::post($url,$p);$r=xn_json_decode($raw);if(!is_array($r))throw new Exception('易支付返回数据无效');
  if($version==='v2'&&(empty($r['sign'])||!self::rsaVerify($r,$settings['epay_public_key']??'')))throw new Exception('易支付V2返回验签失败');
  if(intval($r['code']??0)!==1)throw new Exception('易支付下单失败：'.strval($r['msg']??'未知错误'));
  if(!empty($r['payurl']))return array('type'=>'redirect','url'=>self::safeRedirect($r['payurl']),'trade_no'=>$r['trade_no']??'');
  if(!empty($r['urlscheme']))return array('type'=>'redirect','url'=>self::safeRedirect($r['urlscheme']),'trade_no'=>$r['trade_no']??'');
  if(!empty($r['qrcode']))return array('type'=>'native','code_url'=>$r['qrcode'],'trade_no'=>$r['trade_no']??'');
  throw new Exception('易支付未返回支付链接或二维码');
 }
 public static function verifyNotify($p,$settings){
  if(!is_array($p)||empty($p['sign']))return false;
  if(strval($p['pid']??'')!==trim($settings['epay_pid']??''))return false;
  try{$version=strtoupper(strval($p['sign_type']??''))==='MD5'?'v1':'v2';
  $parts=explode('|',strval($p['param']??''));if(count($parts)>=3&&end($parts)!==$version)return false;
  if($version==='v2'){
   $rawTs=strval($p['timestamp']??'');$ts=ctype_digit($rawTs)?intval($rawTs):intval(strtotime($rawTs));if($ts<=0||abs(time()-$ts)>600)return false;
   return self::rsaVerify($p,$settings['epay_public_key']??'');
  }
  return hash_equals(self::md5Sign($p,$settings['epay_key']??''),strtolower(strval($p['sign'])));}catch(Throwable $e){return false;}
 }
 private static function canonical($p){unset($p['sign'],$p['sign_type']);ksort($p,SORT_STRING);$a=array();foreach($p as $k=>$v)if(!is_array($v)&&$v!==''&&$v!==null)$a[]=$k.'='.$v;return implode('&',$a);}
 private static function md5Sign($p,$key){$key=trim($key);if($key==='')throw new Exception('易支付V1商户密钥未配置');return md5(self::canonical($p).$key);}
 private static function rsaSign($p,$key){$k=openssl_pkey_get_private(self::privatePem($key));if(!$k)throw new Exception('易支付V2商户私钥无效');if(!openssl_sign(self::canonical($p),$sig,$k,OPENSSL_ALGO_SHA256))throw new Exception('易支付V2签名失败');return base64_encode($sig);}
 private static function rsaVerify($p,$key){$sig=base64_decode(strval($p['sign']??''),true);if($sig===false)return false;$k=openssl_pkey_get_public(self::publicPem($key));return $k&&openssl_verify(self::canonical($p),$sig,$k,OPENSSL_ALGO_SHA256)===1;}
 private static function privatePem($v){$v=trim($v);if(strpos($v,'-----BEGIN ')!==false)return $v;$v=str_replace(array("\r","\n"),'',$v);return "-----BEGIN PRIVATE KEY-----\n".chunk_split($v,64,"\n")."-----END PRIVATE KEY-----";}
 private static function publicPem($v){$v=trim($v);if(strpos($v,'-----BEGIN ')!==false)return $v;$v=str_replace(array("\r","\n"),'',$v);return "-----BEGIN PUBLIC KEY-----\n".chunk_split($v,64,"\n")."-----END PUBLIC KEY-----";}
 private static function base($v){$v=trim(strval($v));$u=parse_url($v);if(!is_array($u)||strtolower(strval($u['scheme']??''))!=='https'||empty($u['host'])||isset($u['user'])||isset($u['pass'])||isset($u['query'])||isset($u['fragment']))throw new Exception('易支付接口地址格式无效，请填写 HTTPS 地址');$path=rtrim(strval($u['path']??''),'/');$path=preg_replace('#/(?:submit|mapi)\.php$#i','',$path);$path=preg_replace('#/api/v2/pay/create$#i','',$path);$port=isset($u['port'])?':'.intval($u['port']):'';return 'https://'.strval($u['host']).$port.$path;}
 private static function safeRedirect($v){$v=trim(strval($v));if(!preg_match('#^(https://|weixin://|alipays://)#i',$v))throw new Exception('易支付返回了不安全的跳转地址');return $v;}
 private static function device(){ $ua=$_SERVER['HTTP_USER_AGENT']??'';if(stripos($ua,'MicroMessenger')!==false)return 'wechat';if(stripos($ua,'AlipayClient')!==false)return 'alipay';return stripos($ua,'Mobile')!==false?'mobile':'pc';}
 private static function post($url,$p){$ch=curl_init($url);curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($p,'','&',PHP_QUERY_RFC3986),CURLOPT_HTTPHEADER=>array('Content-Type: application/x-www-form-urlencoded;charset=utf-8'),CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>20,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2));$raw=curl_exec($ch);if($raw===false){$e=curl_error($ch);curl_close($ch);throw new Exception('易支付请求失败：'.$e);} $http=intval(curl_getinfo($ch,CURLINFO_HTTP_CODE));curl_close($ch);if($http<200||$http>=300)throw new Exception('易支付接口 HTTP '.$http);return $raw;}
}
