<?php
!defined('DEBUG') AND exit('Access Denied');
class AlipayOfficialService {
 public static function payUrl($order,$settings,$notifyUrl,$returnUrl,$mobile){
  $biz=array('out_trade_no'=>$order['order_no'],'total_amount'=>number_format(intval($order['amount']),2,'.',''),'subject'=>$order['subject'],'product_code'=>$mobile?'QUICK_WAP_WAY':'FAST_INSTANT_TRADE_PAY');
  $p=array('app_id'=>trim($settings['alipay_appid']),'method'=>$mobile?'alipay.trade.wap.pay':'alipay.trade.page.pay','format'=>'JSON','charset'=>'utf-8','sign_type'=>'RSA2','timestamp'=>date('Y-m-d H:i:s'),'version'=>'1.0','notify_url'=>$notifyUrl,'return_url'=>$returnUrl,'biz_content'=>xn_json_encode($biz));
  $p['sign']=self::sign($p,$settings['alipay_private_key']);
  return trim($settings['alipay_gateway']).'?'.http_build_query($p,'','&',PHP_QUERY_RFC3986);
 }
 public static function precreate($order,$settings,$notifyUrl){
  $biz=array('out_trade_no'=>$order['order_no'],'total_amount'=>number_format(intval($order['amount']),2,'.',''),'subject'=>$order['subject'],'timeout_express'=>'30m');
  $p=array('app_id'=>trim($settings['alipay_appid']),'method'=>'alipay.trade.precreate','format'=>'JSON','charset'=>'utf-8','sign_type'=>'RSA2','timestamp'=>date('Y-m-d H:i:s'),'version'=>'1.0','notify_url'=>$notifyUrl,'biz_content'=>xn_json_encode($biz));
  $p['sign']=self::sign($p,$settings['alipay_private_key']);
  $ch=curl_init(trim($settings['alipay_gateway']));curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($p,'','&',PHP_QUERY_RFC3986),CURLOPT_HTTPHEADER=>array('Content-Type: application/x-www-form-urlencoded;charset=utf-8'),CURLOPT_TIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2));$raw=curl_exec($ch);if($raw===false){$e=curl_error($ch);curl_close($ch);throw new Exception('支付宝请求失败：'.$e);} $http=intval(curl_getinfo($ch,CURLINFO_HTTP_CODE));curl_close($ch);$json=xn_json_decode($raw);$r=$json['alipay_trade_precreate_response']??array();if($http!==200||($r['code']??'')!=='10000'||empty($r['qr_code']))throw new Exception(($r['sub_msg']??($r['msg']??'支付宝面对面下单失败')).' ['.strval($r['sub_code']??$r['code']??$http).']');return $r;
 }
 public static function query($order,$settings){
  $biz=array('out_trade_no'=>$order['order_no']);
  $p=array('app_id'=>trim($settings['alipay_appid']),'method'=>'alipay.trade.query','format'=>'JSON','charset'=>'utf-8','sign_type'=>'RSA2','timestamp'=>date('Y-m-d H:i:s'),'version'=>'1.0','biz_content'=>xn_json_encode($biz));
  $p['sign']=self::sign($p,$settings['alipay_private_key']);
  $ch=curl_init(trim($settings['alipay_gateway']));curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($p,'','&',PHP_QUERY_RFC3986),CURLOPT_HTTPHEADER=>array('Content-Type: application/x-www-form-urlencoded;charset=utf-8'),CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2));$raw=curl_exec($ch);if($raw===false){$e=curl_error($ch);curl_close($ch);throw new Exception('支付宝订单查询失败：'.$e);} $http=intval(curl_getinfo($ch,CURLINFO_HTTP_CODE));curl_close($ch);
  $json=xn_json_decode($raw);$r=is_array($json)?($json['alipay_trade_query_response']??array()):array();$body=self::responseObject($raw,'alipay_trade_query_response');$sig=is_array($json)?strval($json['sign']??''):'';
  if($http!==200||!is_array($r)||$body===''||!self::verifyText($body,$sig,$settings['alipay_public_key']))throw new Exception('支付宝订单查询响应验签失败');
  return $r;
 }
 public static function verify($params,$publicKey){
  $sign=base64_decode(strval($params['sign']??''),true);if($sign===false)return false;
  unset($params['sign'],$params['sign_type']);ksort($params);$pairs=array();foreach($params as $k=>$v)if($v!==''&&$v!==null)$pairs[]=$k.'='.$v;
  $key=openssl_pkey_get_public(self::publicPem($publicKey));if(!$key)return false;
  return openssl_verify(implode('&',$pairs),$sign,$key,OPENSSL_ALGO_SHA256)===1;
 }
 private static function sign($params,$privateKey){
  ksort($params);$pairs=array();foreach($params as $k=>$v)if($v!==''&&$v!==null)$pairs[]=$k.'='.$v;
  $key=openssl_pkey_get_private(self::privatePem($privateKey));if(!$key)throw new Exception('支付宝应用私钥无效');
  openssl_sign(implode('&',$pairs),$signature,$key,OPENSSL_ALGO_SHA256);return base64_encode($signature);
 }
 private static function verifyText($text,$signature,$publicKey){$sig=base64_decode($signature,true);if($sig===false)return false;$key=openssl_pkey_get_public(self::publicPem($publicKey));return $key&&openssl_verify($text,$sig,$key,OPENSSL_ALGO_SHA256)===1;}
 private static function responseObject($json,$name){$needle='"'.$name.'"';$p=strpos($json,$needle);if($p===false)return '';$p=strpos($json,'{',$p+strlen($needle));if($p===false)return '';$depth=0;$quoted=false;$escaped=false;$len=strlen($json);for($i=$p;$i<$len;$i++){$c=$json[$i];if($quoted){if($escaped){$escaped=false;continue;}if($c==='\\'){$escaped=true;continue;}if($c==='"')$quoted=false;continue;}if($c==='"'){$quoted=true;continue;}if($c==='{')$depth++;elseif($c==='}'&&--$depth===0)return substr($json,$p,$i-$p+1);}return '';}
 private static function privatePem($v){$v=trim($v);if(strpos($v,'-----BEGIN ')!==false)return $v;$v=str_replace(array("\r","\n"),'',$v);return "-----BEGIN PRIVATE KEY-----\n".chunk_split($v,64,"\n")."-----END PRIVATE KEY-----";}
 private static function publicPem($v){$v=trim($v);if(strpos($v,'-----BEGIN ')!==false)return $v;$v=str_replace(array("\r","\n"),'',$v);return "-----BEGIN PUBLIC KEY-----\n".chunk_split($v,64,"\n")."-----END PUBLIC KEY-----";}
}
