<?php
!defined('DEBUG') AND exit('Access Denied');
class WechatPayV3Service {
 const HOST='https://api.mch.weixin.qq.com';
 public static function create($order,$channel,$openid,$s,$notifyUrl){
  $map=array('wechat_native'=>'/v3/pay/transactions/native','wechat_h5'=>'/v3/pay/transactions/h5','wechat_jsapi'=>'/v3/pay/transactions/jsapi');$path=$map[$channel]??'';if($path==='')throw new Exception('微信支付类型无效');
  $body=array('appid'=>trim($s['wechat_appid']),'mchid'=>trim($s['wechat_mchid']),'description'=>$order['subject'],'out_trade_no'=>$order['order_no'],'notify_url'=>$notifyUrl,'amount'=>array('total'=>intval($order['amount'])*100,'currency'=>'CNY'));
  if($channel==='wechat_h5')$body['scene_info']=array('payer_client_ip'=>ip(),'h5_info'=>array('type'=>'Wap'));
  if($channel==='wechat_jsapi')$body['payer']=array('openid'=>$openid);
  $r=self::request('POST',$path,$body,$s);if($channel==='wechat_native'&&empty($r['code_url']))throw new Exception($r['message']??'微信 Native 下单失败');if($channel==='wechat_h5'&&empty($r['h5_url']))throw new Exception($r['message']??'微信 H5 下单失败');if($channel==='wechat_jsapi'&&empty($r['prepay_id']))throw new Exception($r['message']??'微信 JSAPI 下单失败');return $r;
 }
 public static function jsapiParams($prepayId,$s){$p=array('appId'=>trim($s['wechat_appid']),'timeStamp'=>strval(time()),'nonceStr'=>xn_rand(16),'package'=>'prepay_id='.$prepayId,'signType'=>'RSA');$msg=$p['appId']."
".$p['timeStamp']."
".$p['nonceStr']."
".$p['package']."
";$p['paySign']=self::rsaSign($msg,$s['wechat_private_key']);return $p;}
 public static function oauthUrl($orderNo,$s,$callback){$state=$orderNo.'.'.hash_hmac('sha256',$orderNo,trim($s['wechat_app_secret']));return 'https://open.weixin.qq.com/connect/oauth2/authorize?'.http_build_query(array('appid'=>trim($s['wechat_appid']),'redirect_uri'=>$callback,'response_type'=>'code','scope'=>'snsapi_base','state'=>$state)).'#wechat_redirect';}
 public static function verifyState($state,$s){$a=explode('.',$state,2);return count($a)===2&&hash_equals(hash_hmac('sha256',$a[0],trim($s['wechat_app_secret'])),$a[1])?$a[0]:'';}
 public static function fetchOpenid($code,$s){$url='https://api.weixin.qq.com/sns/oauth2/access_token?'.http_build_query(array('appid'=>trim($s['wechat_appid']),'secret'=>trim($s['wechat_app_secret']),'code'=>$code,'grant_type'=>'authorization_code'));$r=self::curl('GET',$url,array(),'',10);$j=xn_json_decode($r['body']);if(empty($j['openid']))throw new Exception($j['errmsg']??'获取微信 openid 失败');return $j['openid'];}
 public static function verifyAndDecrypt($headers,$body,$s){$ts=$headers['wechatpay-timestamp']??'';$nonce=$headers['wechatpay-nonce']??'';$sig=base64_decode($headers['wechatpay-signature']??'',true);if(!$ts||!$nonce||$sig===false||abs(time()-intval($ts))>300)return false;$cert=openssl_pkey_get_public(trim($s['wechat_platform_cert']));if(!$cert||openssl_verify($ts."
".$nonce."
".$body."
",$sig,$cert,OPENSSL_ALGO_SHA256)!==1)return false;$j=xn_json_decode($body);$r=$j['resource']??array();$cipher=base64_decode($r['ciphertext']??'',true);if($cipher===false||strlen($cipher)<17)return false;$tag=substr($cipher,-16);$plain=openssl_decrypt(substr($cipher,0,-16),'aes-256-gcm',trim($s['wechat_api_v3_key']),OPENSSL_RAW_DATA,$r['nonce']??'',$tag,$r['associated_data']??'');return $plain===false?false:xn_json_decode($plain);}
 private static function request($method,$path,$data,$s){$body=$data?xn_json_encode($data):'';$ts=time();$nonce=xn_rand(16);$msg=$method."
".$path."
".$ts."
".$nonce."
".$body."
";$auth='WECHATPAY2-SHA256-RSA2048 mchid="'.trim($s['wechat_mchid']).'",nonce_str="'.$nonce.'",timestamp="'.$ts.'",serial_no="'.trim($s['wechat_serial_no']).'",signature="'.self::rsaSign($msg,$s['wechat_private_key']).'"';$r=self::curl($method,self::HOST.$path,array('Accept: application/json','Content-Type: application/json','Authorization: '.$auth),$body,15);$j=xn_json_decode($r['body']);if($r['code']<200||$r['code']>=300)throw new Exception($j['message']??('微信支付 HTTP '.$r['code']));return $j;}
 private static function rsaSign($message,$privateKey){$k=openssl_pkey_get_private(trim($privateKey));if(!$k)throw new Exception('微信商户私钥无效');openssl_sign($message,$sig,$k,OPENSSL_ALGO_SHA256);return base64_encode($sig);}
 private static function curl($method,$url,$headers,$body,$timeout){$ch=curl_init($url);curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>$timeout,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2));if($body!=='')curl_setopt($ch,CURLOPT_POSTFIELDS,$body);$out=curl_exec($ch);if($out===false){$e=curl_error($ch);curl_close($ch);throw new Exception('网络请求失败：'.$e);} $code=intval(curl_getinfo($ch,CURLINFO_HTTP_CODE));curl_close($ch);return array('code'=>$code,'body'=>$out);}
}
