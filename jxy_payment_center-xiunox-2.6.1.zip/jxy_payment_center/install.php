<?php
!defined('DEBUG') AND exit('Access Denied');
global $db,$conf;
// 保留 db_exec
db_exec("CREATE TABLE IF NOT EXISTS {$db->tablepre}pc_payment_order (
 id int unsigned NOT NULL AUTO_INCREMENT, order_no varchar(32) NOT NULL DEFAULT '', uid int unsigned NOT NULL DEFAULT 0,
 amount int unsigned NOT NULL DEFAULT 0, channel varchar(20) NOT NULL DEFAULT '', subject varchar(128) NOT NULL DEFAULT '',
 credit_type varchar(16) NOT NULL DEFAULT 'rmbs', credit_amount int unsigned NOT NULL DEFAULT 0, bonus_amount int unsigned NOT NULL DEFAULT 0,
 status tinyint unsigned NOT NULL DEFAULT 0, provider_trade_no varchar(128) NOT NULL DEFAULT '', client_ip int unsigned NOT NULL DEFAULT 0,
 created int unsigned NOT NULL DEFAULT 0, paid_at int unsigned NOT NULL DEFAULT 0, updated int unsigned NOT NULL DEFAULT 0,
 pay_payload text NOT NULL, callback_raw text NOT NULL,
 PRIMARY KEY(id), UNIQUE KEY order_no(order_no), KEY uid_created(uid,created), KEY status_created(status,created)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
// 保留 db_exec
db_exec("CREATE TABLE IF NOT EXISTS {$db->tablepre}pc_wechat_user (
 uid int unsigned NOT NULL DEFAULT 0, openid varchar(128) NOT NULL DEFAULT '', updated int unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY(uid), UNIQUE KEY openid(openid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
setting_set('payment_center',array(
 'enabled'=>0,'show_nav'=>1,'channels'=>array('alipay','wechat_native','wechat_h5','wechat_jsapi'),'min_amount'=>1,'max_amount'=>10000,'order_expire'=>1800,
 'ratio_rmbs'=>1,'ratio_credits'=>10,'ratio_golds'=>1,'preset_amounts'=>array(1,5,10,30,50,100),'preset_bonuses'=>array(0,0,0,0,0,0),
 'alipay_appid'=>'','alipay_private_key'=>'','alipay_public_key'=>'','alipay_gateway'=>'https://openapi.alipay.com/gateway.do','alipay_mode'=>'f2f',
 'wechat_appid'=>'','wechat_app_secret'=>'','wechat_mchid'=>'','wechat_serial_no'=>'','wechat_private_key'=>'','wechat_api_v3_key'=>'','wechat_platform_cert'=>'','epay_version'=>'v1','epay_gateway'=>'','epay_pid'=>'','epay_key'=>'','epay_private_key'=>'','epay_public_key'=>'',
 'notice'=>'充值到账以支付平台异步通知为准，请勿重复付款。'
));
if(isset($conf['tmp_path'])&&function_exists('xn_unlink')) @xn_unlink($conf['tmp_path'].'model.min.php');
