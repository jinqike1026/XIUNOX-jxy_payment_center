<?php
!defined('DEBUG') AND exit('Access Denied');
global $db;
// 2.3.0：新增 RMB、积分、金币充值目标与订单比例快照。
// 保留 db_sql_find
$cols=db_sql_find("SHOW COLUMNS FROM {$db->tablepre}pc_payment_order");$names=array();foreach($cols?:array() as $c)$names[$c['Field']]=1;
// 保留 db_exec
if(!isset($names['pay_payload'])) db_exec("ALTER TABLE {$db->tablepre}pc_payment_order ADD COLUMN pay_payload text NOT NULL AFTER updated");
// 保留 db_exec
if(isset($names['channel'])) db_exec("ALTER TABLE {$db->tablepre}pc_payment_order MODIFY channel varchar(20) NOT NULL DEFAULT ''");
// 保留 db_exec
if(!isset($names['credit_type'])) db_exec("ALTER TABLE {$db->tablepre}pc_payment_order ADD COLUMN credit_type varchar(16) NOT NULL DEFAULT 'rmbs' AFTER subject");
// 保留 db_exec
if(!isset($names['credit_amount'])) db_exec("ALTER TABLE {$db->tablepre}pc_payment_order ADD COLUMN credit_amount int unsigned NOT NULL DEFAULT 0 AFTER credit_type");
// 保留 db_exec
if(!isset($names['bonus_amount'])) db_exec("ALTER TABLE {$db->tablepre}pc_payment_order ADD COLUMN bonus_amount int unsigned NOT NULL DEFAULT 0 AFTER credit_amount");
// 保留 db_exec
db_exec("UPDATE {$db->tablepre}pc_payment_order SET credit_type='rmbs' WHERE credit_type='' OR credit_type IS NULL");
// 保留 db_exec
db_exec("UPDATE {$db->tablepre}pc_payment_order SET credit_amount=amount WHERE credit_amount=0");
// 保留 db_exec
db_exec("CREATE TABLE IF NOT EXISTS {$db->tablepre}pc_wechat_user (uid int unsigned NOT NULL DEFAULT 0,openid varchar(128) NOT NULL DEFAULT '',updated int unsigned NOT NULL DEFAULT 0,PRIMARY KEY(uid),UNIQUE KEY openid(openid)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
// 2.5.7：将支付充值的积分记录说明改为中文，并同步更新历史记录。
// 保留 db_exec
db_exec("UPDATE {$db->tablepre}credits_log SET reason=REPLACE(reason,'payment_recharge:rmbs:','支付中心充值：RMB：') WHERE reason LIKE 'payment_recharge:rmbs:%'");
// 保留 db_exec
db_exec("UPDATE {$db->tablepre}credits_log SET reason=REPLACE(reason,'payment_recharge:credits:','支付中心充值：积分：') WHERE reason LIKE 'payment_recharge:credits:%'");
// 保留 db_exec
db_exec("UPDATE {$db->tablepre}credits_log SET reason=REPLACE(reason,'payment_recharge:golds:','支付中心充值：金币：') WHERE reason LIKE 'payment_recharge:golds:%'");
$old=setting_get('payment_center');
$d=array('enabled'=>0,'show_nav'=>1,'channels'=>array('alipay','wechat_native','wechat_h5','wechat_jsapi'),'min_amount'=>1,'max_amount'=>10000,'order_expire'=>1800,'ratio_rmbs'=>1,'ratio_credits'=>10,'ratio_golds'=>1,'preset_amounts'=>array(1,5,10,30,50,100),'preset_bonuses'=>array(0,0,0,0,0,0),'alipay_appid'=>'','alipay_private_key'=>'','alipay_public_key'=>'','alipay_gateway'=>'https://openapi.alipay.com/gateway.do','alipay_mode'=>'f2f','wechat_appid'=>'','wechat_app_secret'=>'','wechat_mchid'=>'','wechat_serial_no'=>'','wechat_private_key'=>'','wechat_api_v3_key'=>'','wechat_platform_cert'=>'','epay_version'=>'v1','epay_gateway'=>'','epay_pid'=>'','epay_key'=>'','epay_private_key'=>'','epay_public_key'=>'','notice'=>'充值到账以支付平台异步通知为准，请勿重复付款。');
if(is_array($old)){foreach(array_keys($d) as $k)if(isset($old[$k]))$d[$k]=$old[$k];}
setting_set('payment_center',$d);
plugin_clear_tmp_dir();
